# What is the difference between justify-content and align-items?
Justify content aligns items on the main axis while align items aligns on the cross axis.
# How do you use flexbox to completely center a div inside a flex container?
Set justify content and align items to center.
# What’s the difference between justify-content: space-between and justify-content: space-around?
All the space is between the elements in space between while it is around the elements in space around.