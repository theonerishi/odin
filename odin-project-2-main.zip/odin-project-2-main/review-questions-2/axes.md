# How do you make flex items arrange themselves vertically instead of horizontally?
flex-direction: column
# In a column flex-container, what does flex-basis refer to?
The minimum size of the flex item. In this case the minimum height.
# In a row flex-container, what does flex-basis refer to?
The minimum width.
# Why do the previous two questions have different answers?
The flex direction is different.