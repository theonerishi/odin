# What is the difference between a block element and an inline element?
Block level elements sit on a new line while inline elements don't.
# What is the difference between an inline element and an inline-block element?
Width and height are respected in inline-block while it isn't in inline.
# Is an h1 block or inline?
Block.
# Is button block or inline?
Inline.
# Is div block or inline?
Block.
# Is span block or inline?
Inline.