# What are two benefits of having well-written commit messages and a good commit history?
To remember the thought process in case you would like to add or improve functionality and it helps you stand out in the job search.
# How many characters should the subject line of your commit message be?
Up to 50 characters.