# Why would you want to use em or rem for font-size instead of px?
So that elements automatically adjust when you change font size.
# What are some instances where you might want to use vh and vw?
When you want something to be displayed relative to the screen.
# What are some instances where you might want to use px instead of a relative unit?
When you want the size of something to be static.