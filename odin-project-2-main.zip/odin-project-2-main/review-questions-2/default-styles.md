# Why would you want to use a CSS reset?
To prevent default formatting from incorrectly altering the layout of elements.
# Are resets required?
Not mandatory.