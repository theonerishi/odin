# What is an HTML tag?
A HTML tag go around content to specify an element.
# What are the three parts of an HTML element?
Opening tag, closing tag and the content.
# What are void elements, and how are they different from regular HTML elements?
They have no closing tag while regular elements have a closing tag.