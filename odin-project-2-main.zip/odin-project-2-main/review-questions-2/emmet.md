# Why should you use Emmet?
It offers a shorthand method for producing frequently used code.
# What are some useful Emmet abbreviations?
! then enter
element name then . for class or # for id then * number of elements then > followed by nested elements put content in () with content then enter
# What syntax would you use to create the element <p class="text"></p>?
p.text
# What syntax expands to an element with a child element inside of it? For example: <div><p></p></div>
div>p
# What syntax would you use to create three elements that have the same class name?
.className*3