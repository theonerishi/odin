# What are functions useful for?
Reusing code without having to type all the code all over again.
# How do you invoke a function?
functionName(parameter1, parameter2)
# What are anonymous functions?
Functions without a name that can be passed onto other functions such as addEventListener to use shorter syntax.
# What is function scope?
Function scope is to do with what variables are accessible outside a function.
# What are return values?
Values that are returned from a function.
# What are arrow functions?
Short anonymous function syntax using the arrow => that can be passed onto another function.
# What is the difference between a function declaration and a function expression?
A function expression is where you set a function to a variable whereas function declarations use the standard syntax.