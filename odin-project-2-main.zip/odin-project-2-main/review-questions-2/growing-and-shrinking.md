# What are the 3 values defined in the shorthand flex property (e.g. flex: 1 1 auto)?
flex-grow: 1
flex-shrink: 1
flex-basis: auto
# What are the 3 defined values for the flex shorthand flex: auto?
flex: 1 1 auto;