# What is the purpose of the doctype declaration?
To state the type of file.
# What is the HTML element?
HTML opening and closing tags that contain the content of the website.
# What is the purpose of the head element?
Contains information about the webpage.
# What is the purpose of the body element?
Contains the content of the webpage.