# How do you select a specific element on your page with your browser’s developer tools?
Click on the element or click on the pointer icon and then hover over an element.
# What does a strikethrough in a CSS declaration mean in your browser’s developer tools?
It shows styles being overwritten.
# How do you change CSS in real time on specific elements of a web page with your browser’s developer tools?
You can edit the code in the developer pane.