# What is the syntax for class and ID selectors?
. and #
# How would you apply a single rule to two different selectors?
using ,
# Given an element that has an id of title and a class of primary, how would you use both attributes for a single rule?
.primary#title
# What does the descendant combinator do?
Allows you to select elements nested within other elements.
# What are the names of the three ways to add CSS to HTML?
Inline, external, internal
# What are the main differences between the three ways of adding CSS to HTML?
External is preferred to keep the HTML code clean.