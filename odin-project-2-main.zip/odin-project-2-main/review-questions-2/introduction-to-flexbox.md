# What is the difference between a flex container and a flex item?
Flex items belong in the flex container. display: flex is applied to the flex container.
# How do you create a flex item?
display: flex