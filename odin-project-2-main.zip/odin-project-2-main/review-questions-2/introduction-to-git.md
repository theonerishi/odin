# What kind of program is Git?
Git is version control software that keeps a history of each save known as a commit.
# What are the differences between Git and a text editor in terms of what they save and their record keeping?
Git keeps a record of each save while a text editor does not.
# Does Git work at a local or remote level?
Git works locally.
# Does GitHub work at a local or remote level?
GitHub works remotely.
# Why is Git useful for developers?
It allows the developer to revert to previous versions of code.
# Why are Git and GitHub useful for a team of developers?
It allows each user to see what changes have been made to code and who made them.
