# What do HTML and CSS stand for?
HTML stands for HyperText Markup Language. CSS stands for Cascading Style Sheets.
# Between HTML and CSS, which would you use for putting paragraphs of text on a webpage?
HTML
# Between HTML and CSS, which would you use for changing the font and background color of a button?
CSS
# What is the difference between HTML, CSS and JavaScript?
HTML lays out the content of the webpage, CSS is for styling, Javascript is for interactivity.