# How do you open developer tools?
Right click and then click on Inspect.
# How do you change screen size of a website using developer tools?
Use device mode and select a mobile device screen size or manually set screen size.
# What is a breakpoint?
Where code stops in a debugger.
# How do you set a breakpoint?
Click on the light red circle to the left of code and it should become a dark red circle.