# What element is used to create a link?
The a tag.
# What is an attribute?
A property that adds information to an element and may change how content is displayed.
# What attribute tells links where to go to?
href
# What security considerations must be taken if you wish to use the target attribute to open links in a new tab/window?
target='_blank'
# What is the difference between an absolute and relative link?
A relative link is on the same web page and is denoted in the simplest case by ./filename while an absolute link may be on a different web page and the full URL is stated.
# Which element is used to display an image?
The img tag.
# What two attributes do images always need to have?
src and alt
# How do you access a parent directory in a filepath?
..
# What are the four main image formats that you can use for images on the web?
jpg, gif, png and svg