# What HTML element is used to create an unordered list?
The ul tag.
# What HTML element is used to create an ordered list?
The ol tag.
# What HTML element is used to create list items within both unordered and ordered lists?
The li tag.