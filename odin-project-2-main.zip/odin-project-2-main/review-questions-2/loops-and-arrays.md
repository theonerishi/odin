# What are loops useful for?
Repeating code instead of having to type it out all over again.
# What is the break statement?
To stop further iterations of the loop.
# What is the continue statement?
To continue to the next iteration.
# What is an array?
Stores multiple values next to each other on the computer.
# What are arrays useful for?
Storing groups of variables.
# How do you access or change an array element?
Indexing starts at zero. Elements can
# What are some useful array methods?
sort, map, filter, reduce, push, pop, shift, unshift, splice, slice etc.
# What is the advantage of writing automated tests?
It allows us to know whether the code works.