# What is the difference between objects and arrays?
Objects store data in key value pairs while arrays store data values.
# How do you access object properties?
Use bracket or dot notation.
# How do primitives and object types differ when you assign them to other variables, or pass them into functions?
A copy of data is passed to a function with primitives while a reference to the original object is passed onto a function when using objects.