# What are the three stages in the problem solving process?
Plan, write pseudocode and divide and conquer.
# Why is it important to clearly understand the problem first?
To understand what pseudocode has to be written.
# What can you do to help get a clearer understanding of the problem?
Ask questions about what the program should do.
# What are some of the things you should do in the planning stage of the problem solving process?
Ask questions such as whether the program should have a user interface, what functionality should it have etc.
# What is an algorithm?
A program that takes an input, performs a process and generates an output.
# What is pseudocode?
Writing out the steps that need to be done in a program in plain English.
# What are the advantages of breaking a problem down and solving the smaller problems?
Makes solving problems more manageable.