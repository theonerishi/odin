# What are branches in git?
Separate versions of code that represents different pathways when developing a program.
# How do you create a new branch?
git branch
# How do you merge a branch back into main?
git merge
# What is one use case for branches?
Allows you to develop new features with working code as a fallback.