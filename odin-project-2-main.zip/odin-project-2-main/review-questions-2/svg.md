# What is the xmlns attribute?
XML namespace- specifies what dialect of XML you are using.
# What are some situations where you wouldn’t want to use SVG?
When photos are complex.
# What are the benefits of “inlining” your SVGs?
You can edit the svg.
# What are the drawbacks?
Makes code look complex.