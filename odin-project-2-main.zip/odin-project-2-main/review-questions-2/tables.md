# What is a table?
Data made up of rows and columns to allow the reader to find the relationship between the data.
# Why is it a bad idea to use HTML Tables for page layout?
Has been replaced by CSS.
# What are caption elements useful for?
Describing what the table is about.
# What is the scope attribute?
Tells the reader what kind of header cell you are on.