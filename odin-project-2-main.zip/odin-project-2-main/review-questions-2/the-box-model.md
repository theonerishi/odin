# From inside to outside, what is the order of box-model properties?
padding, border, margin
# What does the box-sizing CSS property do?
Includes padding and border in width/ height.
# What is the difference between the standard and alternative box model?
The alternative box model includes padding and border in width/ height while the standard box model does not.
# Would you use margin or padding to create more space between 2 elements?
margin
# Would you use margin or padding to create more space between the contents of an element and its border?
padding
# Would you use margin or padding if you wanted two elements to overlap each other?
set a negative margin
# How do you set the alternative box model for all of your elements?
use the *
# How do you center an element horizontally?
margin: 0 auto;