# Between a rule that uses one class selector and a rule that uses three type selectors, which rule has the higher specificity?
The class selector