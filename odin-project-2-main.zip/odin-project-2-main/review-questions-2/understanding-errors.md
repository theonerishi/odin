# What are three reasons why you may see a TypeError?
When an operand or argument is passed to a function that is incompatible, when trying to modify a value that cannot be changed or when you try to use a value in the wrong way.
# What is the key difference between an error and a warning?
Errors prevent the program from running while warnings do not.
# What is one method you can use to resolve an error?
Reading the error message