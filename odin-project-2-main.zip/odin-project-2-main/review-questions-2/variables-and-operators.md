# What three keywords can you use to declare new variables?
var, let and const
# Which of the three variable declarations should you avoid and why?
You should avoid const when you need a variable that can change.
# What rules should you follow when naming variables?
The name must contain only letters, digits or some symbols and the first character should not be a digit.
# What happens when you add numbers and strings together?
The number is converted to a string then concatenated.
# How does the Modulo (%), or Remainder, operator work?
# What’s the difference between == and ===?
The modulo operator returns the remainder of a division. === only returns true if the value and type are the same while == does not.
# When would you receive a NaN result?
When doing arithmetic with a value that isn't a number.
# How do you increment and decrement a number?
i++ and i--
# What’s the difference between prefixing and postfixing increment/decrement operators?
The prefix returns the new value while the postfix returns the old value.
# What is operator precedence and how is it handled in JS?
Same as in mathematics- multiplication and division before addition and subtraction.
# How do you access developer tools and the console?
Right click and click inspect.
# How do you log information to the console?
console.log(value)
# What does unary plus operator do to string representations of integers? eg. +”10”
Converts a string into a number.