# How do you create a paragraph in HTML?
The p tag.
# How do you create a heading in HTML?
The h1 tag.
# How many different levels of headings are there and what is the difference between them?
There are 6 levels. Each successive level is smaller.
# What element should you use to make text bold and important?
The strong tag.
# What element should you use to make text italicized to add emphasis to it?
The em tag.
# What relationship does an element have with any nested elements within it?
Parent.
# What relationship do two elements have if they are at the same level of nesting?
Sibling
# How do you create HTML comments?
The comment tag.